"use strict";
/*    

      Author: Pierre Fandy Francois
      Date:   10/26/2025

      Filename: orders.js
*/

// Page Objects
let submitButton = document.getElementById("submitButton");
let product = document.getElementById("product");
let price = document.getElementById("price");
let quantity = document.getElementById("quantity");
let size = document.getElementById("size");
let color = document.getElementById("color");

submitButton.onclick = function() {
   let itemTotal;
   // Increase the total items in the shopping cart by 1
   if (sessionStorage.getItem("itemsInCart")) {
      itemTotal = parseInt(sessionStorage.getItem("itemsInCart"), 10) + 1;
   } else {
      itemTotal = 1;
   }
   
   // Store the number of items in the shopping cart
   sessionStorage.setItem("itemsInCart", itemTotal);
   
   // Create a text string describing the product added to the cart,
   // with each field separated by " & "
   let itemText = product.value + " & ";
   itemText += price.value + " & ";
   itemText += quantity.value + " & ";
   itemText += size.value + " & ";
   itemText += color.value;

   // Create a new shopping cart storage item with the key name "cartItem" plus the item number
   sessionStorage.setItem("cartItem" + itemTotal, itemText);
};