"use strict";
/*    
      Author: Pierre Fandy Francois
      Date:   10/26/2025

      Filename: cart.js
*/

// Page Objects
let cartContainer = document.getElementById("cartContainer");

window.addEventListener("load", displayCart);

// Function to construct the table containing items placed in the shopping cart
function displayCart() {
   // Check that there are items in the shopping cart
   if (sessionStorage.getItem("itemsInCart")) {
      let itemTotal = parseInt(sessionStorage.getItem("itemsInCart"), 10);
      
      // Create the code for the table and the table header
      let cartTable = document.createElement("table");
      cartTable.id = "cartTable";
      let tableHeader = `<tr><th>Product</th><th>Description</th><th>Qty</th><th>Price</th></tr>`;
      cartTable.innerHTML = tableHeader;
      
      // For each item in the shopping cart, write a table row
      for (let i = 1; i <= itemTotal; i++) {
         
         // Retrieve information about a product added to the cart
         // Stored format: product & price & quantity & size & color
         const stored = sessionStorage.getItem("cartItem" + i);
         if (!stored) continue; // skip missing items (defensive)
         
         let productArr = stored.split(" & ");
         let newRow = document.createElement("tr");
         
         // Display the name of the product
         let productCell = document.createElement("td");
         productCell.textContent = productArr[0] || "";
         newRow.appendChild(productCell);
         
         // Display a description of the product (size and color)
         let descriptionCell = document.createElement("td");
         descriptionCell.textContent = (productArr[3] || "") + ", " + (productArr[4] || "");
         newRow.appendChild(descriptionCell);
         
         // Display the quantity ordered
         let qtyCell = document.createElement("td");
         qtyCell.textContent = productArr[2] || "";
         newRow.appendChild(qtyCell); 
         
         // Display the price of the item
         let priceCell = document.createElement("td");
         priceCell.textContent = productArr[1] || "";
         newRow.appendChild(priceCell); 
         
         cartTable.appendChild(newRow);
      }
      
      if (cartContainer) cartContainer.appendChild(cartTable);
   }
}